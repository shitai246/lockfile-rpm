#!/bin/sh
lockfile -c

